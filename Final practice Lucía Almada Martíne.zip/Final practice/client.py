import http.client
import json

SERVER = "localhost"
PORT = 8080


def request(path):
    conn = http.client.HTTPConnection(SERVER, PORT)
    conn.request("GET", path)
    response = conn.getresponse()
    return json.loads(response.read().decode())

print("\n--- listSpecies ---")
data = request("/listSpecies?limit=10&json=1")
print(data)

print("\n--- karyotype ---")
data = request("/karyotype?species=mouse&json=1")
print(data)

print("\n--- chromosomeLength ---")
data = request("/chromosomeLength?species=mouse&chromo=18&json=1")
print(data)

print("\n--- geneLookup ---")
data = request("/geneLookup?gene=FRAT1&json=1")
print(data)

print("\n--- geneSeq ---")
data = request("/geneSeq?gene=FRAT1&json=1")
print(data["sequence"][:50])

print("\n--- geneInfo ---")
data = request("/geneInfo?gene=FRAT1&json=1")
print(data)

print("\n--- geneCalc ---")
data = request("/geneCalc?gene=FRAT1&json=1")
print(data)

print("\n--- geneList ---")
data = request("/geneList?chromo=7&start=140000000&end=140600000&json=1")
print(data)