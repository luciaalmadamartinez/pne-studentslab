import http.server
import socketserver
import jinja2 as j
from urllib.parse import parse_qs, urlparse
from pathlib import Path
import http.client
import json
from Seq1 import Seq
PORT = 8080

socketserver.TCPServer.allow_reuse_address = True
class TestHandler(http.server.BaseHTTPRequestHandler):

    #pongo esta función aquí para no interrumpir la estructura if, elif pero realmente no se usa hasta el path /geneLookup
    def get_gene_id(self, gene):

        SERVER = 'rest.ensembl.org'
        ENDPOINT = f'/lookup/symbol/homo_sapiens/{gene}'
        PARAMS = '?content-type=application/json'

        conn = http.client.HTTPConnection(SERVER)
        conn.request("GET", ENDPOINT + PARAMS)

        response = conn.getresponse()
        data = json.loads(response.read().decode())

        if "id" in data:
            gene_id = data["id"]
        else:
            gene_id = None

        return gene_id

    def is_json(self, arguments):
        return arguments.get("json", ["0"])[0] == "1"

    def send_json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def send_error_html(self):

        filename = "html/error.html"

        with open(filename, "r", encoding="utf-8") as f:
            body = f.read()

        self.send_response(404)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(body.encode())

    def read_html_file(self, filename):
        contents = Path("html/" + filename).read_text(encoding="utf-8")
        content = j.Template(contents)
        return content

    def do_GET(self):
        url_path = urlparse(self.path)
        path = url_path.path
        arguments = parse_qs(url_path.query)
        print(arguments)

        json_mode = self.is_json(arguments)
        file = self.path.strip("/")

        if file == "" or file == "index.html":
            filename = "html/index.html"
            with open(filename, "r", encoding="utf-8") as f:
                body = f.read()
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(body.encode())

        elif path == "/listSpecies":
            try:
                SERVER = 'rest.ensembl.org'
                ENDPOINT = '/info/species'
                PARAMS = '?content-type=application/json'

                conn = http.client.HTTPConnection(SERVER)
                conn.request("GET", ENDPOINT + PARAMS)

                response = conn.getresponse()
                data = json.loads(response.read().decode())

                limit = int(arguments["limit"][0])
                species = data["species"]
                i = 0
                total_species = 0
                names_list = []

                for specie in species:
                    total_species += 1
                    if "common_name" in specie and i < limit:
                        names_list.append(specie["common_name"])
                        i += 1

                if json_mode:
                    return self.send_json({
                        "total_species": total_species,
                        "limit": limit,
                        "species": names_list
                    })

                body = self.read_html_file("listSpecies.html").render(context={"total_species": total_species, "limit": limit, "species": names_list})

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()

        elif path == "/karyotype":

            try:

                species = arguments["species"][0]

                SERVER = 'rest.ensembl.org'
                ENDPOINT = f'/info/assembly/{species}'
                PARAMS = '?content-type=application/json'

                conn = http.client.HTTPConnection(SERVER)
                conn.request("GET", ENDPOINT + PARAMS)

                response = conn.getresponse()

                if response.status != 200:
                    return self.send_error_html()

                data = json.loads(response.read().decode())

                if "karyotype" not in data:
                    return self.send_error_html()

                karyotype = data["karyotype"]

                if json_mode:
                    return self.send_json({
                        "species": species,
                        "karyotype": karyotype
                    })

                body = self.read_html_file("karyotype.html").render(
                    context={
                        "species": species,
                        "karyotype": karyotype
                    }
                )

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()

        elif path == "/chromosomeLength":

            try:
                species = arguments["species"][0]
                chromo = arguments["chromo"][0]

                SERVER = 'rest.ensembl.org'
                ENDPOINT = f'/info/assembly/{species}'
                PARAMS = '?content-type=application/json'

                conn = http.client.HTTPConnection(SERVER)
                conn.request("GET", ENDPOINT + PARAMS)

                response = conn.getresponse()
                data = json.loads(response.read().decode())

                if "top_level_region" in data:
                    chromosomes = data["top_level_region"]
                else:
                    return self.send_error_html()
                found = False
                for chromosome in chromosomes:
                    if chromosome["name"] == chromo:
                        length = chromosome["length"]
                        found = True

                if not found:
                    return self.send_error_html()

                if json_mode:
                    return self.send_json({
                        "species": species,
                        "chromosome": chromo,
                        "length": length
                    })

                body = self.read_html_file("chromosomeLength.html").render(context={"length": length})

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()


        elif path == "/geneLookup":

            try:
                gene = arguments["gene"][0]
                gene_id = self.get_gene_id(gene)

                if gene_id is None:
                    return self.send_error_html()

                if json_mode:
                    return self.send_json({
                        "gene": gene,
                        "gene_id": gene_id
                    })

                body = self.read_html_file("geneLookup.html").render(context={"gene": gene, "gene_id": gene_id})

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()


        elif path == "/geneSeq":

            try:
                gene = arguments["gene"][0]
                gene_id = self.get_gene_id(gene)

                if gene_id is None:
                    return self.send_error_html()

                SERVER = 'rest.ensembl.org'
                ENDPOINT = f'/sequence/id/{gene_id}'
                PARAMS = '?content-type=application/json'

                conn = http.client.HTTPConnection(SERVER)
                conn.request("GET", ENDPOINT + PARAMS)

                response = conn.getresponse()
                data = json.loads(response.read().decode())

                if "seq" in data:
                    sequence = data["seq"]

                if json_mode:
                    return self.send_json({
                        "gene_id": gene_id,
                        "sequence": sequence
                    })

                body = self.read_html_file("geneSeq.html").render(context={"gene_id": gene_id, "sequence": sequence})

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()

        elif path == "/geneInfo":

            try:
                gene = arguments["gene"][0]
                gene_id = self.get_gene_id(gene)

                if gene_id is None:
                    return self.send_error_html()

                SERVER = 'rest.ensembl.org'
                ENDPOINT = f'/lookup/id/{gene_id}'
                PARAMS = '?content-type=application/json'

                conn = http.client.HTTPConnection(SERVER)
                conn.request("GET", ENDPOINT + PARAMS)

                response = conn.getresponse()
                data = json.loads(response.read().decode())

                result = {
                    "start": data["start"],
                    "end": data["end"],
                    "length": data["end"] - data["start"] + 1,
                    "chromosome": data["seq_region_name"]
                }

                if json_mode:
                    return self.send_json(result)

                start = data["start"]
                end = data["end"]
                length = end - start + 1
                chromosome = data["seq_region_name"]

                body = self.read_html_file("geneInfo.html").render(context={"gene_id": gene_id, "start": start, "end": end, "length": length, "chromosome": chromosome})

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()

        elif path == "/geneCalc":

            try:
                gene = arguments["gene"][0]
                gene_id = self.get_gene_id(gene)

                if gene_id is None:
                    return self.send_error_html()

                SERVER = 'rest.ensembl.org'
                ENDPOINT = f'/sequence/id/{gene_id}'
                PARAMS = '?content-type=application/json'

                conn = http.client.HTTPConnection(SERVER)
                conn.request("GET", ENDPOINT + PARAMS)

                response = conn.getresponse()
                data = json.loads(response.read().decode())

                if "seq" in data:
                    sequence = data["seq"]

                s = Seq(sequence)
                length = s.len()
                base_count = s.count()

                num_total = sum(base_count.values())

                result = {
                    "length": s.len(),
                    "percentages": {
                        b: round((v / num_total) * 100, 3) if num_total else 0
                        for b, v in base_count.items()
                    }
                }

                if json_mode:
                    return self.send_json(result)

                body = self.read_html_file("geneCalc.html").render(context={"length": result["length"], "percentages": result["percentages"]})

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()

        elif path == "/geneList":
            try:
                chromo = arguments["chromo"][0]
                start = arguments["start"][0]
                end = arguments["end"][0]

                SERVER = 'rest.ensembl.org'
                ENDPOINT = f'/overlap/region/human/{chromo}:{start}-{end}'
                PARAMS = '?content-type=application/json;feature=gene'

                conn = http.client.HTTPConnection(SERVER)
                conn.request("GET", ENDPOINT + PARAMS)

                response = conn.getresponse()
                data = json.loads(response.read().decode())

                if not data or "error" in data:
                    return self.send_error_html()

                genes = [
                    g.get("external_name", g.get("id"))
                    for g in data if g
                ]

                if json_mode:
                    return self.send_json({
                        "chromosome": chromo,
                        "start": start,
                        "end": end,
                        "genes": genes
                    })

                body = self.read_html_file("geneList.html").render(context={"chromosome": chromo, "start": start, "end": end, "genes": genes})

                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(body.encode())

            except Exception:
                return self.send_error_html()



def run(server_class=socketserver.TCPServer, handler_class=TestHandler):
    with server_class(("", PORT), handler_class) as httpd:
        print(f"Server running on http://localhost:{PORT}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped")
            httpd.server_close()

if __name__ == "__main__":
    run()